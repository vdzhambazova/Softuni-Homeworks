﻿namespace P08MilitaryElite.Interfaces
{
    public interface IPrivate
    {
        double Salary { get; }
    }
}