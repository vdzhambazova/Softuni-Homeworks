﻿namespace P08MilitaryElite.Interfaces
{
    public interface ISpy
    {
        int CodeNumber { get; }
    }
}