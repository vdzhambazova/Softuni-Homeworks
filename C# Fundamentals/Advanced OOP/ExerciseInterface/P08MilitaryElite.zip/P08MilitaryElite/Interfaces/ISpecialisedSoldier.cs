﻿namespace P08MilitaryElite.Interfaces
{
    public interface ISpecialisedSoldier
    {
        string Corps { get;}
    }
}