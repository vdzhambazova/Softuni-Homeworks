﻿namespace P08MilitaryElite.Interfaces
{
    public interface ISolder
    {
        string Id { get;}
        string FirstName { get; }
        string LastName { get; }
    }
}