﻿namespace P01DefineInterfaceIPerson
{
    internal class Citizen
    {
    }
}