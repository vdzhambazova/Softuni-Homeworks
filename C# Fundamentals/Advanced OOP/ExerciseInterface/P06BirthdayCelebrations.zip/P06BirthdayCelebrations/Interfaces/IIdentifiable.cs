﻿namespace P06BirthdayCelebrations.Interfaces
{
    public interface IIdentifiable
    {
        string Id { get; set; }
    }
}
