﻿namespace P09CollectionHierarchy.Interfaces
{
    public interface IAddable
    {
        int Add(string element);
    }
}
