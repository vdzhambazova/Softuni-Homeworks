﻿namespace P09CollectionHierarchy.Interfaces
{
    public interface IRemovable
    {
        string Remove();
    }
}
