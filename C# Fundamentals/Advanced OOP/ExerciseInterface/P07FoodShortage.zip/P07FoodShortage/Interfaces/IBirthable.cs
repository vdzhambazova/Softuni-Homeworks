﻿namespace P07FoodShortage.Interfaces
{
    public interface IBirthable
    {
        string BirthDate { get; set; }
    }
}
