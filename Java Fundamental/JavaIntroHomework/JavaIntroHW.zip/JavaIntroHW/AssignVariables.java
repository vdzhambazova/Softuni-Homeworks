public class AssignVariables {

    public static void main(String[] args) {

        byte a = 127;
        short b = 32767;
        int c = 2000000000;
        long d = 919827112351L;
        char e = 'c';
        boolean f = false;
        float g = 0.5f;
        double h = 0.123456789101;
        String j = "Palo Alto, CA";
    }
}
